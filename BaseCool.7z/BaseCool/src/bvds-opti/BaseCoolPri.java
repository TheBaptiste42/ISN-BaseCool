package bvds;

import javax.swing.JFrame;

public class BaseCoolPri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Attention tout nombre sup�rieur � 999 999 999 999 999 999 fera PLANTER LE PROGRAMME ET PROBABLEMENT VOTRE ORDINATEUR !!!!!
		String[] nom = {"St�phane Gentilhomme Le B�cheron", "Anonyme"};
		JOptionPane jop = new JOptionPane();
		int rang = jop.showOptionDialog(null, "Veuillez indiquer votre nom !", "GIGN", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, nom, nom[0]);

		Fenetre fen = new Fenetre();
	}

}
