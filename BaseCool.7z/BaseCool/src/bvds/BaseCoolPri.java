package bvds;

import javax.swing.JFrame;

public class BaseCoolPri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Attention tout nombre sup�rieur � 999 999 999 999 999 999 fera PLANTER LE PROGRAMME ET PROBABLEMENT VOTRE ORDINATEUR !!!!!
		Fenetre fen = new Fenetre();
	}

}
